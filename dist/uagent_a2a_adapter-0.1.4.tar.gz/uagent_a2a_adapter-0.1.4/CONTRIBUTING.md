# Contributing to uAgent A2A Adapter

Thank you for your interest in contributing to the uAgent A2A Adapter! This document provides guidelines and information for contributors.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please treat all community members with respect and create a welcoming environment for everyone.

## How to Contribute

### Reporting Issues

Before creating an issue, please:

1. **Search existing issues** to avoid duplicates
2. **Use a clear and descriptive title**
3. **Provide detailed information** about the problem
4. **Include steps to reproduce** the issue
5. **Add relevant logs or error messages**
6. **Specify your environment** (Python version, OS, etc.)

### Suggesting Enhancements

Enhancement suggestions are welcome! Please:

1. **Check if the enhancement already exists** in issues or discussions
2. **Provide a clear description** of the proposed feature
3. **Explain the use case** and benefits
4. **Consider implementation complexity** and maintenance burden

### Pull Requests

1. **Fork the repository** and create your branch from \`main\`
2. **Follow the development setup** instructions below
3. **Make your changes** with clear, focused commits
4. **Add or update tests** for your changes
5. **Update documentation** if needed
6. **Ensure all tests pass** and code is properly formatted
7. **Submit a pull request** with a clear description

## Development Setup

### Prerequisites

- Python 3.8 or higher
- Git
- Virtual environment tool (venv, conda, etc.)

### Setup Instructions

1. **Clone your fork:**
   \`\`\`bash
   git clone https://github.com/gautammanak1/uagent-a2a-adapter.git
   cd uagent-a2a-adapter
   \`\`\`

2. **Create a virtual environment:**
   \`\`\`bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\\Scripts\\activate
   \`\`\`

3. **Install development dependencies:**
   \`\`\`bash
   pip install -e .[dev]
   \`\`\`

4. **Install pre-commit hooks (optional but recommended):**
   \`\`\`bash
   pre-commit install
   \`\`\`

### Development Workflow

1. **Create a feature branch:**
   \`\`\`bash
   git checkout -b feature/your-feature-name
   \`\`\`

2. **Make your changes** following the coding standards below

3. **Run tests:**
   \`\`\`bash
   pytest
   \`\`\`

4. **Format code:**
   \`\`\`bash
   black .
   isort .
   \`\`\`

5. **Check types:**
   \`\`\`bash
   mypy uagent_a2a_adapter
   \`\`\`

6. **Lint code:**
   \`\`\`bash
   flake8 uagent_a2a_adapter
   \`\`\`

7. **Commit your changes:**
   \`\`\`bash
   git add .
   git commit -m "feat: add your feature description"
   \`\`\`

8. **Push to your fork:**
   \`\`\`bash
   git push origin feature/your-feature-name
   \`\`\`

9. **Create a pull request** on GitHub

## Coding Standards

### Python Style

- Follow **PEP 8** style guidelines
- Use **Black** for code formatting (line length: 88)
- Use **isort** for import sorting
- Use **type hints** for all functions and methods
- Write **docstrings** for all public functions, classes, and modules

### Code Quality

- **Write tests** for new functionality
- **Maintain test coverage** above 80%
- **Use meaningful variable names** and comments
- **Keep functions small** and focused
- **Handle errors gracefully** with appropriate logging

### Commit Messages

Use conventional commit format:

- \`feat:\` for new features
- \`fix:\` for bug fixes
- \`docs:\` for documentation changes
- \`test:\` for test additions/changes
- \`refactor:\` for code refactoring
- \`style:\` for formatting changes
- \`chore:\` for maintenance tasks

Example: \`feat: add support for custom message handlers\`

## Testing

### Running Tests

\`\`\`bash
# Run all tests
pytest

# Run with coverage
pytest --cov=uagent_a2a_adapter --cov-report=html

# Run specific test file
pytest tests/test_adapter.py

# Run tests with verbose output
pytest -v
\`\`\`

### Writing Tests

- Place tests in the \`tests/\` directory
- Use descriptive test names: \`test_adapter_handles_message_correctly\`
- Test both success and failure cases
- Use fixtures for common test setup
- Mock external dependencies appropriately

### Test Structure

\`\`\`python
import pytest
from unittest.mock import Mock, patch
from uagent_a2a_adapter import A2AAdapter

class TestA2AAdapter:
    def test_adapter_initialization(self):
        # Test adapter creation
        pass
    
    @pytest.mark.asyncio
    async def test_message_handling(self):
        # Test async message handling
        pass
\`\`\`

## Documentation

### Docstring Format

Use Google-style docstrings:

\`\`\`python
def example_function(param1: str, param2: int) -> bool:
    """Brief description of the function.
    
    Longer description if needed, explaining the purpose,
    behavior, and any important details.
    
    Args:
        param1: Description of the first parameter.
        param2: Description of the second parameter.
        
    Returns:
        Description of the return value.
        
    Raises:
        ValueError: Description of when this exception is raised.
        
    Example:
        \`\`\`python
        result = example_function("hello", 42)
        print(result)  # True
        \`\`\`
    """
    return True
\`\`\`

### README Updates

When adding new features:

1. Update the feature list
2. Add usage examples
3. Update configuration documentation
4. Add any new dependencies to installation instructions

## Release Process

Releases are handled by maintainers:

1. Update version in \`pyproject.toml\`
2. Update \`CHANGELOG.md\`
3. Create a release tag
4. Publish to PyPI
5. Create GitHub release

## Getting Help

If you need help:

1. **Check the documentation** first
2. **Search existing issues** and discussions
3. **Ask in GitHub Discussions** for general questions
4. **Create an issue** for bugs or specific problems
5. **Contact maintainers** via email if needed

## Recognition

Contributors will be recognized in:

- GitHub contributors list
- Release notes for significant contributions
- Special mentions for major features or fixes

Thank you for contributing to the uAgent A2A Adapter! 🚀
\`\`\`

```text file="LICENSE"
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (which shall not include communications that are marked or
      otherwise designated in writing by the copyright owner as
      "Not a Work").

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based upon (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and derivative works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control
      systems, and issue tracking systems that are managed by, or on behalf
      of, the Licensor for the purpose of discussing and improving the Work,
      but excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to use, reproduce, modify, distribute, and prepare
      Derivative Works of, and to display and perform the Work and such
      Derivative Works in all media and formats whether now known or
      hereafter devised.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, trademark, patent,
          attribution and other notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
      notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright notice to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Support. You may choose to offer, and to
      charge a fee for, warranty, support, indemnity or other liability
      obligations and/or rights consistent with this License. However, in
      accepting such obligations, You may act only on Your own behalf and on
      Your sole responsibility, not on behalf of any other Contributor, and
      only if You agree to indemnify, defend, and hold each Contributor
      harmless for any liability incurred by, or claims asserted against,
      such Contributor by reason of your accepting any such warranty or support.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same page as the copyright notice for easier identification within
      third-party archives.

   Copyright 2025 gautammanak

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
